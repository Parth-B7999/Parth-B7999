%==========================================================================         
% File Name     : <qsolver.m>                                                       
% Usage         : [sol, how, lambda, fval] = qsolver(Q, c, A, b, x0, EqIdx, options)
% Description   : This function provides a link between MATLAB and several          
% commercial solvers [CPLEX,NAG]. It provides the solution to the following         
% optimization problem                                                              
%     min_{x} 1/2 x^T*Q*x + c^T*x                                                   
%     s.t.    Ax <= b                                                               
% where x0 is the initial guess (optional). Note that the solver options            
% set in 'OptionSet' are used. Additionally note that the polytope Ax <= b          
% should be closed, otherwise unbounded solutions might result. You can             
% check for unboundedness using the function 'Const2Bounds'.                        
%                                                                                   
% The options are set in the function 'OptionSet.m' unless otherwise                
% specified in the optional entry 'options'.                                        
%--------------------------------------------------------------------------         
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,                       
%                 Efstratios N. Pistikopoulos                                       
% Office        : Engineering Research Building, Texas A&M University, USA          
% Mail          : paroc@tamu.edu                                                    
%--------------------------------------------------------------------------         
% Last Revision | Author  | Description                                             
%---------------+---------+------------------------------------------------         
% 25-Mar-2014   | RO      | Initial Version                                         
%---------------+---------+------------------------------------------------         
% 25-May-2016   | RO      | Inclusing of objective function value                   
%==========================================================================         
