%==========================================================================
% File Name     : <McCormick.m>                                            
% Usage         : [Estimate, delta] = McCormick(Quad, CR, n, options)      
% Description   : This function returns a linear approximation of a general
% quadratic function f(x) = x' * Q * x + c' * x + d inside a critical      
% region, based on a McCormick reformulation for the bilinear/quadratic    
% terms.                                                                   
% f(x) >= u2x1 + u1x2 - u1u2   (1)                                         
% f(x) >= l2x1 + l1x2 - l1l2   (2)                                         
% f(x) <= u2x1 + l1x2 - l1u2   (3)                                         
% f(x) <= l2x1 + u1x2 - u1l2   (4)                                         
%                                                                          
% The input n defines how many estimator shall be returned. Currently      
% n = {1,2}                                                                
% The second output is delta, the maximum difference between the quadratic 
% function and the linear approximator, which is given by                  
% delta = t1^{min}*t2^{min} + t1^{max}*t2^{max} - t1^{min}*t2^{max} -      
%          t1^{max}*t2^{min}                                               
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 14-Feb-2014   | RO      | Initial Version                                
%==========================================================================
