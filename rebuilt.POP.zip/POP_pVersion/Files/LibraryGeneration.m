%==========================================================================
% File Name     : <LibraryGeneration.m>                                    
% Usage         : Stats = LibraryGeneration(Folder,options)                
% Description   : This function takes a folder or array of problems        
% containing a set of mp-LP/mp-QP/mp-MILP/mp-MIQP problems, solves all the 
% problems (if possible), and returns (a) the updated folder containing the
% number of critical regions etc. such that it is straight up usable in    
% POP, (b) the statistics for the solution [timing information, infeasible,
% fails] and (c) a .mat file containing all the solutions. These are stored
% separately, as the storage space becomes very quickly unmanagable.       
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 26-Oct-2015   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 29-Oct-2015   | RO      | Added array of problems functionality          
%==========================================================================
