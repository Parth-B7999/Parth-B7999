%=========================================================================
% File Name     : <ConnectedGraph.m                                       
% Usage         : [Solution,Time] = ConnectedGraph(problem,options        
% Description   : This function is a mpLP/QP solver, which solves th      
% 'problem' and provides the parametric solution. The approach is based o 
%   Oberdieck, R.; Diangelakis, N.A.; Pistikopoulos, E.N. (2016) A unifie 
%   approach for the solution of multi-parametric linear and quadrati     
%   programming problems. Computers & Chemical Engineering, submitted     
% which implements generates a connected graph as a solution. The require 
% structure of 'problem' can be found in the readme or in the User Guide o
% POP                                                                     
% The options are set in the function 'OptionSet.m' unless otherwis       
% specified in the optional entry 'options'                               
%-------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis              
%                 Efstratios N. Pistikopoulo                              
% Office        : Engineering Research Building, Texas A&M University, US 
% Mail          : paroc@tamu.ed                                           
%-------------------------------------------------------------------------
% Last Revision | Author  | Descriptio                                    
%---------------+---------+-----------------------------------------------
% 09-Mar-2016   | RO      | Initial versio                                
%=========================================================================
