%==========================================================================
% File Name     : <updatePOP.m>                                            
% Usage         : update = updatePOP                                       
% Description   : This function updates the POP toolbox. If 'update = 1',  
% then an update occured, and the list of updated files is reported in     
% 'lsfile'. If 'update = 0', then no update occured.                       
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 11-Apr-2016   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 31-May-2016   | RO      | New file separators                            
%==========================================================================
