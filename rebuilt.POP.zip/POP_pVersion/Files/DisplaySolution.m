%==========================================================================
% File Name     : <DiplaySolution.m>                                       
% Usage         : DisplaySolution(Solution)                                
% Description   : This function displays solution of a mp-P problem.       
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 02-Sep-2014   | RO      | Initial Version                                
%==========================================================================
