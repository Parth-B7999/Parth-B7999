%==========================================================================
% File Name     : <con2vert.m>                                             
% Usage         : [V,nr] = con2vert(A,b)                                   
% Description   : convert a convex set of constraint inequalities into the 
% set of vertices at the intersections of those inequalities; i.e., solve  
% the "vertex enumeration" problem. Additionally, identify redundant       
% entries in the list of inequalities.                                     
%                                                                          
% Converts the polytope (convex polygon, polyhedron, etc.) defined by the  
% system of inequalities A*x <= b into a list of vertices V. Each ROW      
% of V is a vertex. For n variables:                                       
% A = m x n matrix, where m >= n (m constraints, n variables)              
% b = m x 1 vector (m constraints)                                         
% V = p x n matrix (p vertices, n variables)                               
% nr = list of the rows in A which are NOT redundant constraints           
%                                                                          
% NOTES: (1) This program employs a primal-dual polytope method.           
%        (2) In dimensions higher than 2, redundant vertices can           
%            appear using this method. This program detects redundancies   
%            at up to 6 digits of precision, then returns the              
%            unique vertices.                                              
%        (3) Non-bounding constraints give erroneous results; therefore,   
%            the program detects non-bounding constraints and returns      
%            an error. You may wish to implement large "box" constraints   
%            on your variables if you need to induce bounding. For example,
%            if x is a person's height in feet, the box constraint         
%            -1 <= x <= 1000 would be a reasonable choice to induce        
%            boundedness, since no possible solution for x would be        
%            prohibited by the bounding box.                               
%        (4) This program requires that the feasible region have some      
%            finite extent in all dimensions. For example, the feasible    
%            region cannot be a line segment in 2-D space, or a plane      
%            in 3-D space.                                                 
%        (5) At least two dimensions are required.                         
%        (6) See companion function VERT2CON.                              
%--------------------------------------------------------------------------
% Author        : Michael Kleder                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% June-2005     | MK      | ver 1.0: initial version, June 2005            
%---------------+---------+------------------------------------------------
% July-2005     | MK      | ver 1.1: enhanced redundancy checks, July 2005 
%==========================================================================
