%==========================================================================
% File Name     : <POPviaMPT.m>                                            
% Usage         : MPT_problem = POPviaMPT(POP_problem)                     
% Description   : This function provides a way to solve a mp-P problem     
% given in POP-syntax with the MPT toolbox from ETH Zurich. The output is  
% thereby an object of the 'Opt' class as well as the solution to the mp-P 
% problem. Note that the z-transformation needs to be performed, but the   
% reverse cannot be performed due to syntax reason. Hence any comparison   
% with POP needs to involve the reverse z-transformation.                  
%                                                                          
% Note: The time required for the solution is taken from MPT via the       
% command, available in the part '.stats.time' of MPT. Thus, the time      
% required to convert the problem to the POP syntax is NOT part of that    
% solution time.                                                           
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 21-Apr-2015   | RO      | Initial Version                                
%==========================================================================
