%==========================================================================
% File Name     : <addbounds>                                              
% Usage         : [constr, idx] = addbounds(bound, bMax, horz, nocon)      
% Description   : This local function adds constraints for bounds on       
% variables. It accepts bound vector (time independent, one per variable), 
% whether we're setting upper bounds, horizon length and unconstrained     
% intervals. It returns the constraints in local vars mode                 
% (nx*horz columns) with parameters and constant RHS also returns indices  
% of parameters associated with bounds (if any).                           
%--------------------------------------------------------------------------
% Authors       : Richard Oberdieck, Nikolaos Diangelakis, Christos Panos, 
%                 Nikolaos Bozinis, Efstratios N. Pistikopoulos            
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 31-Oct-2015   | RO      | Commenting                                     
%==========================================================================
