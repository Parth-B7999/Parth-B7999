%==========================================================================
% File Name     : <pGeneration.m>                                          
% Usage         : pGeneration(mcode)                                       
% Description   : This function takes as input a .m code or a directory    
% featuring .m files, and (a) generates the corresponding .p code files and
% (b) creates .m file which contains only the top part (comments) in order 
% to enable the command 'help'. Note that if there exists a file and a     
% directory of the same name, the function will always prioritize the      
% directory.                                                               
%                                                                          
% Note: In order to avoid unwanted deletion of files or directories, a new 
% directory will always be created which as the suffix '_pVersion'.        
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 01-Jun-2016   | RO      | Initial Version                                
%==========================================================================
