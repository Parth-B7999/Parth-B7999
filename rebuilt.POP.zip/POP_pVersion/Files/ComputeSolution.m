%==========================================================================
% File Name     : <ComputeSolution.m>                                      
% Usage         : Solution = ComputeSolution(problem, sol_theta)           
% Description   : Given the solution to a mp-P problem this function       
% calculates the corresponding objective function value.                   
%                                                                          
% The objective function value is reported in the following form           
%   z(t) = t'*Q*t + c'*t + d.                                              
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 18-Feb-2014   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 16-Apr-2015   | RO      | Generatization                                 
%==========================================================================
