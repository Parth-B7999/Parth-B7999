%==========================================================================
% File Name     : <RobustMPC.m>                                            
% Usage         : [CP,CPwI,N,mpv] = RobustMPC(ss,mpc,Nmax)                 
% Description   : This function calculates the robust positive invariant   
% (RPI) set of a linear discrete-time system subject to box constraints. It
% thereby implements a version of the algorithm by Pluymers et al.:        
%   Pluymers, B.; Rossiter, J.A., Suykens, J.A.K., De Moor, B. (2005) The  
%   efficient computation of polyhedral invariant sets for linear systems  
%   with polytopic uncertainty. In Proceedings of the American Control     
%   Conference, vol. 2, p. 804-809.                                        
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 20-Jun-2016   | RO      | Initial Version                                
%==========================================================================
