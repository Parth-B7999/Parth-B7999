%=========================================================================
% File Name     : <Combinatorial.m                                        
% Usage         : [Solution,Timing] = Combinatorial(problem, options      
% Description   : This function is a mpLP/QP solver, which solves the     
% 'problem' and provides the parametric solution. The approach is based o 
%   Gupta, A.; Bhartiya, S.; Nataraj, P.S.V. (2011) A novel approach t    
%   multiparametric quadratic programming. Automatica, 47(9): 2112-2117   
% However, on the contrary to the paper, this approach first solves th    
% feasibility LP before continuing to the optimality LP. The require      
% structure of 'problem' can be found in the readme or in the User Guide o
% POP                                                                     
% The options are set in the function 'OptionSet.m' unless otherwis       
% specified in the optional entry 'options'                               
%-------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,             
%                 Efstratios N. Pistikopoulo                              
% Office        : Engineering Research Building, Texas A&M University, US 
% Mail          : paroc@tamu.ed                                           
%-------------------------------------------------------------------------
% Last Revision | Author  | Descriptio                                    
%---------------+---------+-----------------------------------------------
% 09-Mar-2016   | RO      | Initial versio                                
%=========================================================================
