%==========================================================================
% File Name     : <ProblemSet.m>                                           
% Usage         : [problem, ok] = ProblemSet(problem,options)              
% Description   : This sub-routine fills all the undefined fields in the   
% problem structs with zeros and also checks whether the provided problem  
% is feasible/lower-dimensional in the initial parameter space. It also    
% checks for boundedness and adds the appropriate bounding constraints if  
% necessary. Lastly, it also handles inequality and equality constraints,  
% and it removes redundant inequality constraints. In order to switch that 
% feature off, set 'problem.processing = 'Off';'.                          
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 20-Apr-2015   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 31-May-2016   | RO      | Add removal of redundant constraints           
%==========================================================================
