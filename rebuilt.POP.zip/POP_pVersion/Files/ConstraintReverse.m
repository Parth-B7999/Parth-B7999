%==========================================================================
% File Name     : <ConstraintReverse.m>                                    
% Usage         : CRnew = ConstraintReverse(CR_star, CR, options)          
% Description   : This function calculates the remaining critical regions  
% given a solution CR_star and the original critical region CR. It also    
% removes empty or lower-dimensional CRs via the calculation of the        
% Chebyshev ball. The original algorithm has been taken from               
%   Bemporad,A.; Morari,M.; Dua,V.; Pistikopoulos,E.N. (2002) The explicit 
%   linear quadratic regulator for constrained systems. Automatica, 38(1), 
%   3-20.                                                                  
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 23-Mar-2014   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 29-Sep-2015   | RO      | Adaptation to hybrid POP                       
%==========================================================================
