%==========================================================================
% File Name     : <BinContConversion.m>                                    
% Usage         : problem = BinContConversion(problem, Cont2Bin, Bin2Cont) 
% Description   : This function converts a binary/continuous variable      
% in the mp-MILP/mp-MIQP problem into a continuous/binary variable. The    
% inputs are:                                                              
%   problem:    The problem struct used in POP.                            
%   Cont2Bin:   The indices as array of the continuous variables that      
%               should become binary variables. Default is [].             
%   Bin2Cont:   The indices as array of the binary variables that should   
%               become continuous variables. Default is [].                
% For example the definition 'Cont2Bin = [1 5]' would change the 1st and   
% 5th continuous variable into a binary.                                   
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 02-Sep-2014   | RO      | Initial Version                                
%==========================================================================
