%==========================================================================
% File Name     : <UnionOfPolytopes.m>                                     
% Usage         : HybridRegion = UnionOfPolytopes(Region,options)          
% Description   : This function takes as input n Regions in halfspace      
% representation, i.e. Region(k).{A,b} with k = 1,...,n and yields a single
% region HybridRegion.{A,E,b}, which is the equivalent representation of   
% the n Regions using binary variables.                                    
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 11-Jul-2016   | RO      | Initial Version                                
%==========================================================================
