%==========================================================================
% File Name     : <InfeasibleRemoval.m>                                    
% Usage         : problem = InfeasibleRemoval(problem)                     
% Description   :  This helper function removes infeasible constraints from
% the problem formulation by solving 1 LP for each constraint.             
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 01-Dec-2015   | RO      | Initial version                                
%==========================================================================
