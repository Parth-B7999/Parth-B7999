%==========================================================================
% File Name     : <Chebyshev.m>                                            
% Usage         : [x,R] = Chebyshev(A,b,EqIdx,BinIdx)                      
% Description   : This function calculates the Chebyshev center and radius,
% i.e. the location and radius of the ball with the maximum radius within a
% given polyhedron. If the problem is infeasible, it returns x and R as    
% NaN.                                                                     
%                                                                          
% The 3rd and 4th input are optional:                                      
%   EqIdx: If any of the constraints are equality constraints, this can be 
%          specified in this array.                                        
%   BinIdx: If any of the varaibles are binary variables, this can be      
%          specified in this array.                                        
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 17-Apr-2015   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 18-May-2016   | RO      | Add equality and binary variables              
%==========================================================================
