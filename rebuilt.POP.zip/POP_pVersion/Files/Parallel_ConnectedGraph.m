%========================================================================= 
% File Name     : <Parallel_ConnectedGraph.m                               
% Usage         : [Solution,Time] = Parallel_ConnectedGraph(problem,options
% Description   : This function implements the connected graph approach i  
% a parallel way. For more information on the algorithm see the functio    
% 'ConnectedGraph'                                                         
% Note the following                                                       
%   1) Parallelism has inherent overheads. Thus, especially when only 2 o  
%   3 workers are used in parallel, the parallel algorithm might in fact b 
%   slower [significantly] than the sequential versio                      
%   2) The parameter 'rho_limit' regulates how many problems are solved o  
%   a worker in parallel until the results are combined together. Test     
%   have shown that a high value of rho_limit yields good performance fo   
%   the connected graph algorithm. However, if a computational study i     
%   attempted, the user should check several values of rho_limit t         
%   understand its impact                                                  
% The options are set in the function 'OptionSet.m' unless otherwis        
% specified in the optional entry 'options'                                
%------------------------------------------------------------------------- 
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis               
%                 Efstratios N. Pistikopoulo                               
% Office        : Engineering Research Building, Texas A&M University, US  
% Mail          : paroc@tamu.ed                                            
%------------------------------------------------------------------------- 
% Last Revision | Author  | Descriptio                                     
%---------------+---------+----------------------------------------------- 
% 05-Jun-2016   | RO      | Initial versio                                 
%========================================================================= 
