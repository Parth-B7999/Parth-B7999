%==========================================================================
% File Name     : <IntegerFix.m>                                           
% Usage         : problem = IntegerFix(problem, intVec)                    
% Description   : This helper function an mpMIQP problem and a certain     
% combination of integer variables and returns the problem where the       
% integer variables have been fixed.                                       
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 13-Feb-2014   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 18-Sep-2015   | RO      | Make it compliant with new POP                 
%---------------+---------+------------------------------------------------
% 02-Jul-2017   | NAD     | Bug fixes                                      
%==========================================================================
