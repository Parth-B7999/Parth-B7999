%==========================================================================
% File Name     : <ProblemGenerator.m>                                     
% Usage         : [problem,options] = ProblemGenerator(Class,Size,options) 
% Description   : This is a problem generator for multi-parametric         
% programming problems. Given the class of the desired problem ('mpLP',    
% 'mpQP','mpMILP','mpMIQP'), the size of the desired problem:              
%    .x - Number of Continuous Variables                                   
%    .y - Number of Binary Variables                                       
%    .t - Number of Parameters                                             
% and some options (optional input, see Manual for the specifics), it      
% generates a multi-parametric programming problem. It is also possible to 
% specify the number of constraints. However, this number might not be     
% exactly the same in the generated problem if bounding constraints have to
% be added to generate a bounded problem. The output is the random         
% problem(s) 'problem' and the list of options used.                       
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 10-Nov-2014   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 10-Aug-2015   | RO      | Add feasibility check                          
%==========================================================================
