%==========================================================================                          
% File Name     : <VerifySolution.m>                                                                 
% Usage         : [ok,Pts,obj] = VerifySolution(Solution, problem, nPoints, ispar, nworkers, options)
% Description   : This function checks whether the obtained mp-P solution                            
% is indeed correct by comparing the solution for random theta.  The third                           
% argument thereby optionally specifies the number of points, the default                            
% is 5*10^3. The second output gives the points for which the solution                               
% could not be verified (if any).                                                                    
%                                                                                                    
% When the ispar argument (a string) is set to 'parallel' then the algorithm                         
% assigns the solution verification to nworkers. The default operation is                            
% not parallel. In case the parallel functionality is enabled the default                            
% number of workers is 4 (nworkers=4).                                                               
%                                                                                                    
% The options are set in the function 'OptionSet.m' unless otherwise                                 
% specified in the optional entry 'options'.                                                         
%--------------------------------------------------------------------------                          
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis, Baris Burnak,                          
%                 Justin Katz, Efstratios N. Pistikopoulos                                           
% Office        : Engineering Research Building, Texas A&M University, USA                           
% Mail          : paroc@tamu.edu                                                                     
%--------------------------------------------------------------------------                          
% Last Revision | Author  | Description                                                              
%---------------+---------+------------------------------------------------                          
% 16-Apr-2015   | RO      | Initial Version                                                          
%---------------+---------+------------------------------------------------                          
% 25-May-2016   | RO      | Generalize solvers                                                       
%---------------+---------+------------------------------------------------                          
% 31-Jan-2017   | BB, JK  | Initial Version with parallel capability                                 
%==========================================================================                          
