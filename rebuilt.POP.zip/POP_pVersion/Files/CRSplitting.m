%==========================================================================
% File Name     : <CRSplitting.m>                                          
% Usage         : NewUpdate = CRSplitting(Upper, Solution, CR, options)    
% Description   : This function splits a critical regions and assign the   
% correct solutions to the different parts. At the moment it is only called
% to compare two solutions, and then employs the McCormick relaxation to do
% the splitting.                                                           
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 03-Mar-2014   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 25-Sep-2015   | RO      | Adaptation to POP                              
%==========================================================================
