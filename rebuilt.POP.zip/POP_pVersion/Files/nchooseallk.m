%==========================================================================
% File Name     : <nchooseallk.m>                                          
% Usage         : V = nchooseallk(Set, k)                                  
% Description   :  This function is a version of the MATLAB nchoosek       
% function: instead of just giving out all the picks for k number of       
% selections, this function gives all the options for all picks UP to k    
% number of selections.                                                    
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 30-Nov-2015   | RO      | Initial version                                
%==========================================================================
