%==========================================================================
% File Name     : <Bounds2Const.m>                                         
% Usage         : [A, b] = Bounds2Const(Xmin, Xmax, dim)                   
% Description   : Based on a set of bounds Xmin <= x <= Xmax, this function
% calculates the corresponding set of linear inequalities Ax <= b. If the  
% variable is unbound, then no constraint is created.                      
%                                                                          
% The third input is optional, and it denotes the dimension of the         
% variables. This can be used if all the bounds are the same, e.g.         
%  [A, b] = Bounds2Const(-10, 10, 5).                                      
% creates a set of linear inequalities corresponding to a 5-dimensional    
% space with the bounds -10 and 10 on all bounds.                          
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 01-Apr-2015   | RO      | Initial Version                                
%==========================================================================
