%==========================================================================
% File Name     : <FirstRegion.m>                                          
% Usage         : [Solution, Cand] = FirstRegion(problem,options)          
% Description   :  This function performs the first iteration of the mpQP  
% algorithm and yields the first critical region.                          
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 26-Nov-2015   | RO      | Initial version                                
%==========================================================================
