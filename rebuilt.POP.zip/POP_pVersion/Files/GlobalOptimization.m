%==========================================================================
% File Name     : <GlobalOptimization.m>                                   
% Usage         : Integer = GlobalOptimization(problem, Solution, options) 
% Description   : This routine computes the next candidate integer solution
% of the mp-MILP or mp-MIQP problem via global optimization or exhaustive  
% enumeration.                                                             
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 29-Oct-2015   | RO      | Final version for POP                          
%---------------+---------+------------------------------------------------
% 20-Nov-2015   | RO      | Update for POP v1.1                            
%---------------+---------+------------------------------------------------
% 31-May-2016   | RO      | Update for POP v1.6                            
%---------------+---------+------------------------------------------------
% 26-Sep-2016   | RO      | Update for POP v2.0                            
%==========================================================================
