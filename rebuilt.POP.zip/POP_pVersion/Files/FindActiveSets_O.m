%=========================================================================    
% File Name     : <FindActiveSets.m                                           
% Usage         : [ActiveSet, Cand] = FindActiveSets(sol, lam, A, b, EqS, isLP
% Description   : This subroutine finds the active sets associated with th    
% solution 'sol' and current active set 'ActiveSet' of a LP or QP problem     
% Note that in case there is an ambiguity regarding the active set, th        
% second output 'Cand' reports all other possible candidate active sets       
% The inputs are: 'sol' [the solution point 'x']; 'lam' [the values of th     
% Lagrangian multipliers]; 'A'; 'b' [the constraints]; 'EqS' [the indice      
% of 'A' and 'b' which are equality constraints]; isLP [if the problem is     
% mp-LP]                                                                      
%-------------------------------------------------------------------------    
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,                 
%                 Efstratios N. Pistikopoulo                                  
% Office        : Engineering Research Building, Texas A&M University, US     
% Mail          : paroc@tamu.ed                                               
%-------------------------------------------------------------------------    
% Last Revision | Author  | Descriptio                                        
%---------------+---------+-----------------------------------------------    
% 21-Apr-2015   | RO      | Initial Version (based on findactivesetsMS        
%---------------+---------+-----------------------------------------------    
% 11-Aug-2015   | RO      | Final Versio                                      
%---------------+---------+-----------------------------------------------    
% 23-Nov-2015   | RO      | Introduction of 'Cand' outpu                      
%=========================================================================    
