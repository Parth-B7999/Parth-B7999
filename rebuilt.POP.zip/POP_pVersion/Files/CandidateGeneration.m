%==========================================================================
% File Name     : <CandidateGeneration.m>                                  
% Usage         : Lists = CandidateGeneration(Sets, iac, problem)          
% Description   : This function generates all possible candidates from the 
% current active set and the minimal representation of the critical region.
% The function is thereby part of the 'ConnectedGraph' approach, i.e. the  
% fact that the solution to a mp-LP/mp-QP problem is given by a connected  
% graph. For more information, see:                                        
%    Gal, T.; Nedoma, J. (1972) Multiparametric Linear Programming.        
%    Management Science, 18(7), 406-422.                                   
%    Oberdieck, R.; Diangelakis, N.A.; Pistikopoulos, E.N. (2016) Explicit 
%    Model Predictive Control: A connected-graph approach, submitted.      
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 26-Nov-2015   | RO      | Initial version                                
%==========================================================================
