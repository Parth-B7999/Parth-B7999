%=========================================================================
% File Name     : <OptionSet.m                                            
% Usage         : options = OptionSe                                      
% Description   : This file was automatically created by POP              
%                                                                         
% This function contains the options set when the problem was exported. I 
% the user would like to change these options, he or she is kindly referre
% to the user manual, where all the options are listed                    
%-------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,             
%                 Efstratios N. Pistikopoulo                              
% Office        : Engineering Research Building, Texas A&M University, US 
% Mail          : paroc@tamu.ed                                           
%-------------------------------------------------------------------------
% Generation date | Author  | Descriptio                                  
%-----------------+---------+---------------------------------------------
% 18-Dec-2015     | RO      | Automatically generated versio              
%=========================================================================
