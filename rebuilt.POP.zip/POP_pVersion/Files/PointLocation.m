%==========================================================================
% File Name     : <PointLocation.m>                                        
% Usage         : [nCR,x,z,y] = PointLocation(Solution,theta,options)      
% Description   : This function locates the critical region nCR, as well as
% the corresponding solution x and objective function value z for the      
% solution of a mp-P "Solution" and the corresponding parameter value      
% "theta".                                                                 
%                                                                          
% Note: This is a very simple version, i.e. it just loops through all CRs. 
% This means that if the point lies on the border between two critical     
% regions, then the first one which is in the list is picked. Note that it 
% also ignores overlapping critical regions.                               
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 27-Mar-2015   | RO      | Initial Version                                
%==========================================================================
