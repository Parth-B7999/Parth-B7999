%==========================================================================
% File Name     : <qphess.m>                                               
% Usage         : [hx,user,iwsav] = qphess(n,jthcol,hessn,ldh,x,user,iwsav)
% Description   : This is a sub-routine required by NAG.                   
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : C511, Rhoderic Hill, Imperial College London             
% Mail          : paroc@imperial.ac.uk                                     
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 23-Mar-2015   | RO      | Initial Version                                
%==========================================================================
