%==========================================================================
% File Name     : <FixParameter.m>                                         
% Usage         : Solution = FixParameter(Solution,tfixed)                 
% Description   : This function fixes the parameter values to the values   
% specified in 'tfixed'. If it should not be fixed, it should be set to    
% NaN.                                                                     
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 16-Sep-2016   | RO      | Initial version                                
%==========================================================================
