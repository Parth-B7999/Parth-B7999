%==========================================================================
% File Name     : <GetOuter.m>                                             
% Usage         : Outer = GetOuter(Solution, options)                      
% Description   : Based on the solution to a mp-LP/mp-QP problem this      
% function calculates the feasible space 'Outer'.                          
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 12-Jan-2016   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 02-Jul-2017   | RO, NAD | Bug fixes                                      
%==========================================================================
