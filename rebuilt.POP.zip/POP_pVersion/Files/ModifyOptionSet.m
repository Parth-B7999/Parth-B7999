%==========================================================================
% File Name     : <ModifyOptionSet.m>                                      
% Usage         : ModifyOptionSet(options)                                 
% Description   : Given the input struct 'options', this function generates
% a new file 'OptionSet' automatically. This can be helpful to run         
% computational studies for the different algorithms in POP. Note that the 
% input should have the fields which it wants to be modified, e.g.         
%   options.mpSolver = 'Geometrical';                                      
% The different options can be found in the user manual. Those options     
% which are not specified in the input will be set to their default value. 
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Giesecke Engineering Research Building, Texas A&M, USA.  
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 04-May-2016   | RO      | Initial Version                                
%==========================================================================
