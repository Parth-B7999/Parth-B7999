%==========================================================================
% File Name     : <installPOP.m>                                           
% Usage         : installPOP(dir)                                          
% Description   : This function installs the POP toolbox in the directory  
% dir, and automatically adds it to the MATLAB path. If no directory is    
% provided, the MATLAB toolbox directory is automatically used.            
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 11-Apr-2016   | RO      | Initial Version                                
%==========================================================================
