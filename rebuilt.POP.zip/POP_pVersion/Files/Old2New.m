%==========================================================================
% File Name     : <Old2New.m>                                              
% Usage         : problem = Old2New(problem,CR)                            
% Description   : This function converts problem formulations from the old 
% POP toobox into the new syntax. Note that we assume that there are NO    
% equality constraints.                                                    
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 04-Apr-2016   | RO      | Initial Version                                
%==========================================================================
