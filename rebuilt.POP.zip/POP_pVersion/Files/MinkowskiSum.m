%==========================================================================
% File Name     : <MinkowskiSum.m>                                         
% Usage         : Set = MinkowskiSum(SetA,SetB,options)                    
% Description   : This function calculates the Minkowski sum between SetA  
% and SetB, defined in half-space representation.                          
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Sasa V. Rakovic,                      
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 27-Jun-2016   | RO      | Initial version                                
%==========================================================================
