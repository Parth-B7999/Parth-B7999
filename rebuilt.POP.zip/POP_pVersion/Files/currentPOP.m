%==========================================================================
% File Name     : <currentPOP.m>                                           
% Usage         : version = currentPOP                                     
% Description   : This function outputs the current version of POP.        
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 14-Jun-2016   | RO      | Initial Version                                
%==========================================================================
