%==========================================================================
% File Name     : <DeltaSolver.m>                                          
% Usage         : [Tmin, Tmax] = DeltaSolver(Diff, CR, options)            
% Description   : This function solves the delta_min and delta_max problem 
% of the comparison procedure. There are two options for this [see         
% OptionSet]: (a) use 'Approximate', which simply linearizes the objective 
% function intelligently using a McCormick relaxation [for one of the terms
% to preserve convexity] or (b) use 'fmincon', which uses the MATLAB       
% in-built function 'fmincon' to solve the problem. So far, 'fmincon' has  
% proven to be quite robust for this [unlike the 'ExactSolution' function],
% however the computational effort is significantly higher!                
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 22-May-2014   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 02-May-2016   | RO      | Inclusion of fmincon                           
%---------------+---------+------------------------------------------------
% 30-Jun-2017   | NAD     | Inclusion of CPLEX for linear problems         
%==========================================================================
