%==========================================================================  
% File Name     : <normalizeConstraints.m>                                   
% Usage         : [A,b,C,d,set_track] = normalizeConstraints(A,b,C,d,options)
% Description   : This subroutine considers the original system of           
% inequality 'Ax <= b' and equality 'Cx = d' constraints and performs the    
% following:                                                                 
% (i) eliminates zero rows                                                   
% (ii) scales rows so that the maximum value is 1                            
% (iii) eliminates simple redundancies (identical rows)                      
% (iv) detects hidden equality constraints.                                  
% The last entry 'set_track' thereby tracks the indices of the rows of A     
% throughout the function. This is used within mpQP to perform the           
% iterative procedure.                                                       
%                                                                            
% The options are set in the function 'OptionSet.m' unless otherwise         
% specified in the optional entry 'options'.                                 
%--------------------------------------------------------------------------  
% Author        : Unknown, Richard Oberdieck, Nikolaos A. Diangelakis,       
%                 Efstratios N. Pistikopoulos                                
% Office        : Engineering Research Building, Texas A&M University, USA   
% Mail          : paroc@tamu.edu                                             
%--------------------------------------------------------------------------  
% Last Revision | Author  | Description                                      
%---------------+---------+------------------------------------------------  
% 16-Apr-2015   | RO      | Code clean-up, reformulation and commenting      
%==========================================================================  
