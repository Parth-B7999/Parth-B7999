%==========================================================================
% File Name     : <PlotSolution.m>                                         
% Usage         : PlotSolution(Solution, tfixed, option, online, options)  
% Description   : This function plots the critical region, solution or both
% of a multi-parametric programming problem. If only a critical region is  
% plotted, it does not require a solution. The options can be specified in 
% the option field as follows:                                             
%  option = {'CR','OBJ','all'}. The default is 'all'.                      
% The last input is also optional, and it specifies the struct 'online'    
% which is obtained from the function 'ss2qp' when solving a               
% multi-parametric model predictive control problem.                       
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 02-Sep-2014   | RO      | Initial version                                
%---------------+---------+------------------------------------------------
% 23-Dec-2016   | NAD     | Bug fixes                                      
%---------------+---------+------------------------------------------------
% 12-Jul-2016   | NAD     | Added feature: redundant constraints removed   
%               |         | prior to CR plotting                           
%==========================================================================
