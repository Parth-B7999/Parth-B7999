%==========================================================================
% File Name     : <PontryaginDifference.m>                                 
% Usage         : Set = PontryaginDifference(SetA,SetB,options)            
% Description   : This function calculates the Pontryagin difference       
% between SetA and SetB, defined in half-space representation. Currently   
% the function only considers sets which contain the origin.               
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Sasa V. Rakovic,                      
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 27-Jun-2016   | RO      | Initial version                                
%==========================================================================
