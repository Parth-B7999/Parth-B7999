%==========================================================================     
% File Name     : <ParOptConversion.m>                                          
% Usage         : problem = ParOptConversion(problem, Par2Opt, Opt2Par, options)
% Description   : This function converts a parameter/optimization variable      
% in the mp-LP/mp-QP problem into an optimization variable/parameter. The       
% inputs are:                                                                   
%   problem:    The problem struct used in POP.                                 
%   Par2Opt:    The indices as array of the parameters that should become       
%               optimization variables. Default is [].                          
%   Opt2Par:    The indices as array of the optimization variables that         
%               should become parameters. Default is [].                        
% For example the definition 'Par2Opt = [1 5]' would change the 1st and 5th     
% parameter into an optimization variable.                                      
%                                                                               
% The options are set in the function 'OptionSet.m' unless otherwise            
% specified in the optional entry 'options'.                                    
%--------------------------------------------------------------------------     
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,                   
%                 Efstratios N. Pistikopoulos                                   
% Office        : Engineering Research Building, Texas A&M University, USA      
% Mail          : paroc@tamu.edu                                                
%--------------------------------------------------------------------------     
% Last Revision | Author  | Description                                         
%---------------+---------+------------------------------------------------     
% 02-Sep-2014   | RO      | Initial Version                                     
%==========================================================================     
