%==========================================================================
% File Name     : <EqualitySubstitution.m>                                 
% Usage         : problem = EqualitySubstitution(problem)                  
% Description   : This function substitutes all equality constraints in the
% problem formulation. Note that only continuous optimization variables are
% substituted. If there are any other equaltiy constraints - either for    
% binary optimization variables or parameters - then the algorithm gives   
% back problem as empty, as this indicates an ill-defined problem.         
%                                                                          
% Note: Currently, it is not used anywhere in POP. It is a work in progress
% that is included as it might be useful for some users.                   
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 18-Apr-2016   | RO      | Initial Version                                
%==========================================================================
