%==========================================================================       
% File Name     : <miqsolver.m>                                                   
% Usage         : [sol, how, fval] = miqsolver(Q, c, A, b, BinIdx, EqIdx, options)
% Description   : This function provides a unified wrapper for the                
% different MIQP solvers available [cplexmiqp from CPLEX, and exhaustive          
% enumeration]. It provides the solution to the following optimization            
% problem                                                                         
%     min_{x} 1/2 x^T*Q*x + c^T*x                                                 
%     s.t.    Ax <= b                                                             
%             x(BinIdx) binary                                                    
%             A(EqIdx,:)x=b(EqIdx)                                                
% The elements of the problem which are non-continuous are thereby                
% specified by 'BinIdx'. For example, if the 2nd and 10th variable should         
% be binary, set BinIdx = [2,10]. Note that the solver options set in             
% 'OptionSet' are used. Additionally note that the polytope Ax <= b               
% should be compact, otherwise unbounded solutions might result. You can          
% check for unboundedness using the function 'Const2Bounds'.                      
%                                                                                 
% The options are set in the function 'OptionSet.m' unless otherwise              
% specified in the optional entry 'options'.                                      
%--------------------------------------------------------------------------       
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,                     
%                 Efstratios N. Pistikopoulos                                     
% Office        : Engineering Research Building, Texas A&M University, USA        
% Mail          : paroc@tamu.edu                                                  
%--------------------------------------------------------------------------       
% Last Revision | Author  | Description                                           
%---------------+---------+------------------------------------------------       
% 25-Mar-2016   | RO      | Initial Version                                       
%==========================================================================       
