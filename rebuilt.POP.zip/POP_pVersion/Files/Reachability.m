%==========================================================================
% File Name     : <Reachability.m>                                         
% Usage         : Region = Reachability(ss, mpc)                           
% Description   : This function performs the reachability analysis of the  
% state-space system 'ss' and the controller 'mpc', featuring the          
% uncertainty 'epsilona' and 'epsilonb' in the state-space model           
% [box-constrained]. The function is based on:                             
%   Oberdieck, R.; Misener, R.; Pistikopoulos, E.N. (2016) Robust          
%   explicit/multi-parametric control, submitted.                          
% The output is 'Region', which shows the set of initial states for which  
% feasibility can be guaranteed given the considered uncertainty.          
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 31-May-2016   | RO      | Initial Version                                
%==========================================================================
