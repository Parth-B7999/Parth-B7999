%==========================================================================
% File Name     : <scaleRows.m>                                            
% Usage         : [A,b] = scaleRows(A,b)                                   
% Description   : This subroutine scales the constraint rows so that the   
% maximum value == 1. Good scaling is essential for numerical stability and
% various identity tests. Note that row scaling doesn't affect the scaling 
% of the variables themselves, which is a separate issue!                  
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 16-Apr-2015   | RO      | Code clean-up, reformulation and commenting    
%---------------+---------+------------------------------------------------
% 31-May-2016   | RO      | More efficient implementation                  
%==========================================================================
