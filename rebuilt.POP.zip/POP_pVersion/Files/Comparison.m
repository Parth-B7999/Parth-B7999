%==========================================================================
% File Name     : <Comparison.m>                                           
% Usage         : Sol = Comparison(Solution, Upper, Outer, options)        
% Description   : This function provides the different comparison          
% strategies known so far, which are: creating an envelope of solutions,   
% affine comparison (e.g. using McCormick) and exact comparison.           
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 12-May-2014   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 30-Oct-2015   | RO      | Final adaptation                               
%==========================================================================
