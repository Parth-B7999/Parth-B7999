%==========================================================================
% File Name     : <mpQP.m>                                                 
% Usage         : [Solution,Time,Outer] = mpQP(problem,options)            
% Description   : This function solves multi-parametric linear and         
% quadratic programming problems based on the algorithm specified in       
% OptionSet, unless specified otherwise in the optional input 'options'.   
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 08-Mar-2016   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 26-Sep-2016   | RO      | Update to Version 2.0                          
%---------------+---------+------------------------------------------------
% 23-Feb-2017   | NAD     | Bug fixes                                      
%---------------+---------+------------------------------------------------
% 18-Jun-2017   | NAD     | Bug fixes - ActiveSet index (reduced solution) 
%---------------+---------+------------------------------------------------
% 12-Jul-2017   | NAD     | Bug fixes - ActiveSet index (full solution)    
%==========================================================================
