%==========================================================================
% File Name     : <PlotCR.m>                                               
% Usage         : PlotCR(CR,color)                                         
% Description   : This function plots the critical region(s) 'CR', the     
% color of which can be set in the optional field 'color' [RGB color only] 
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 31-May-2016   | RO      | Final version                                  
%==========================================================================
