%=========================================================================
% File Name     : <mpMIQP.m                                               
% Usage         : Solution = mpMIQP(problem,options                       
% Description   :  This function is a mp-MILP/mp-MIQP solver, whic        
% incorporates most of the existing solution approaches. Note that th     
% ability to use the branch-and-bound method has not been incorporated a  
% the associated overhead makes it an inefficient solver                  
% The options are set in the function 'OptionSet.m' unless otherwis       
% specified in the optional entry 'options'                               
%-------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,             
%                 Efstratios N. Pistikopoulo                              
% Office        : Engineering Research Building, Texas A&M University, US 
% Mail          : paroc@tamu.ed                                           
%-------------------------------------------------------------------------
% Last Revision | Author  | Descriptio                                    
%---------------+---------+-----------------------------------------------
% 18-Sep-2015   | RO      | Initial Versio                                
%---------------+---------+-----------------------------------------------
% 02-Jul-2017   | RO, NAD | Bug fixe                                      
%=========================================================================
