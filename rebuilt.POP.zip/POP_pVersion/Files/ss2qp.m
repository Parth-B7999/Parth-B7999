%==========================================================================
% File Name     : <ss2qp.m>                                                
% Usage         : [mpv, online] = ss2qp(mpc, ss)                           
% Description   : This function converts a state-space MPC controller into 
% a mp-QP. It returns the mp-QP equivalent and the online version of the   
% MPC controller. The online version can be used as a quick "parametric"   
% MPC and also has information on variable and parameter vector.           
%                                                                          
%                                                                          
% order of variable vector (dependent stuff on the left)                   
% each subvector ordered according to state-space matrices;                
%                                         earlier time ones start from left
%                                                                          
% The error terms are (Y - Yref) as they appear in the objective, they are 
%         NOT aligned with Yi but however they appear in objective function
%                                                                          
% NEW! "error" terms for U, offering reference points for controls         
%                                                               Eu = U-Uref
% the last optional variable (scalar) is introduced when we have constraint
%                                             slackening (p.99 Maciejowski)
%                                                                          
% variables: [Du0...DuN-1(deltas) y1...yN-1(outputs) x1...xN(states)       
%    e1...eN-1(errors) Eu0...EuN-1(control error) u0...uN-1(controls) soft]
%                                                                          
% Du, Y and Error variables are optional depending on the configuration    
%                                                                          
% naming convention: X=state, U=control, D=disturbance, Y=output           
%--------------------------------------------------------------------------
% Authors       : Richard Oberdieck, Nikolaos Diangelakis, Christos Panos, 
%                 Nikolaos Bozinis, Efstratios N. Pistikopoulos            
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 31-Oct-2015   | RO      | Initial Version                                
%==========================================================================
