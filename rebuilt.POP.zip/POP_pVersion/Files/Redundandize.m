%==========================================================================    
% File Name     : <Redundandize.m>                                             
% Usage         : [A',b',removedRows] = Redundandize(A, b, Xmin, Xmax, options)
% Description   : This function removes redundant constraints from a set of    
% inequalities of the form [the 3rd and 4th input is optional].                
%    Ax <= b                                                                   
%    Xmin <= x <= Xmax                                                         
% The output is the reduced version of the original set of inequalities as     
% well as the indices of the removed rows. Note that it is assumed that the    
% original region is not lower-dimensional.                                    
%                                                                              
% The options are set in the function 'OptionSet.m' unless otherwise           
% specified in the optional entry 'options'.                                   
%--------------------------------------------------------------------------    
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,                  
%                 Efstratios N. Pistikopoulos                                  
% Office        : Engineering Research Building, Texas A&M University, USA     
% Mail          : paroc@tamu.edu                                               
%--------------------------------------------------------------------------    
% Last Revision | Author  | Description                                        
%---------------+---------+------------------------------------------------    
% 23-Mar-2015   | RO      | Initial Version                                    
%---------------+---------+------------------------------------------------    
% 27-Mar-2015   | RO      | Addition of Xmin and Xmax - Use Brearley (1975)    
%---------------+---------+------------------------------------------------    
% 19-Apr-2015   | RO      | Addition to POP                                    
%---------------+---------+------------------------------------------------    
% 31-May-2016   | RO      | More efficient implementation                      
%==========================================================================    
