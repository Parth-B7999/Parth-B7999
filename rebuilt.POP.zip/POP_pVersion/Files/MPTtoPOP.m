%==========================================================================
% File Name     : <MPTtoPOP.m>                                             
% Usage         : POP_Solution = MPTtoPOP(MPT_Solution,problem)            
% Description   : This function converts the solution obtained from the MPT
% toolbox to the equivalent output of the POP toolbox. Note that the second
% input is optional and denotes the original (POP) problem formulation. It 
% is required to calculated the optimal objective function value. While    
% functions such as 'PointLocation' will still work, if you would like to  
% use the output as part of a larger program we suggest that you provide   
% the problem formulation, if possible.                                    
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 03-Nov-2015   | RO      | Initial Version                                
%---------------+---------+------------------------------------------------
% 05-Nov-2015   | RO      | Incorporation into POP syntax                  
%==========================================================================
