%==========================================================================
% File Name     : <SolutionGeneration.m>                                   
% Usage         : Solution = SolutionGeneration(problem,ActiveSets,options)
% Description   : Given the problem formulation and the optimal active     
% sets, this function generates the corresponding parametric solution.     
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@imperial.ac.uk                                     
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 04-Mar-2016   | RO      | Initial version                                
%---------------+---------+------------------------------------------------
% 18-Jun-2017   | NAD     | Bug Fixes                                      
%==========================================================================
