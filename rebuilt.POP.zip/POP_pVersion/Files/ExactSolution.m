%==========================================================================
% File Name     : <ExactSolution.m>                                        
% Usage         : New_Sol = ExactSolution(Solution,options)                
% Description   : This function takes the solution struct featuring        
% envelopes of solutions and polytopic critical regions and provides the   
% exact solution by solving the corresponding QCLP feasibility problems.   
%                                                                          
% Note: The function uses that MATLAB in-built function 'fmincon'.         
% Numerical tests have shown that the solver is incredibly sensitive to the
% tolerances used. Hopefully, a future version of POP will feature a       
% work-around for this problem.                                            
%                                                                          
% The options are set in the function 'OptionSet.m' unless otherwise       
% specified in the optional entry 'options'.                               
%--------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelakis,              
%                 Efstratios N. Pistikopoulos                              
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : paroc@tamu.edu                                           
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 17-Dec-2015   | RO      | Initial Version                                
%==========================================================================
