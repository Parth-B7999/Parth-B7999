%=========================================================================
% File Name     : <OptionSet.m                                            
% Usage         : options = OptionSe                                      
% Description   : This file was automatically created by POP              
%                                                                         
% This function contains the options set when the problem was exported. I 
% the user would like to change these options, he or she is kindly referre
% to the user manual, where all the options are listed                    
%-------------------------------------------------------------------------
% Author        : Richard Oberdieck, Nikolaos A. Diangelaki               
% Office        : Giesecke Engineering Research Building, Texas A&M, USA  
% Mail          : paroc@tamu.ed                                           
%-------------------------------------------------------------------------
% Generation date | Author  | Descriptio                                  
%-----------------+---------+---------------------------------------------
% 09-Apr-2017     | None    | Automatically generated versio              
%=========================================================================
