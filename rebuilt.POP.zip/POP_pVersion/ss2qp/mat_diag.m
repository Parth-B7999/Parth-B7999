%==========================================================================
% File Name     : <mat_diag>                                               
% Usage         : aux = mat_diag(a, b)                                     
% Description   : This function creates symmetric super-matrix putting     
% square matrices in the diagonal, rest padded with zeros                  
%--------------------------------------------------------------------------
% Authors       : Richard Oberdieck, Nikolaos Diangelakis, Christos Panos, 
%                 Nikolaos Bozinis                                         
% Office        : Engineering Research Building, Texas A&M University, USA 
% Mail          : oberdieck@tamu.edu, nikos@tamu.edu                       
%--------------------------------------------------------------------------
% Last Revision | Author  | Description                                    
%---------------+---------+------------------------------------------------
% 31-Oct-2015   | RO      | Commenting                                     
%==========================================================================
